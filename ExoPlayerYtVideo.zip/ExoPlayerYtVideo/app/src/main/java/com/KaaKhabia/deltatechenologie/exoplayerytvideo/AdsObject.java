package com.KaaKhabia.deltatechenologie.exoplayerytvideo;


public class AdsObject {

    AdsObject(){}
}
